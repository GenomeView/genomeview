GenomeView readme

Documentation: http://genomeview.sourceforge.net/content/user-documentation

Download: http://downloads.sourceforge.net/genomeview/

Webstart: http://bioinformatics.psb.ugent.be/webtools/genomeview/launch.jnlp